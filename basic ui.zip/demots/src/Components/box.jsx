// import Card from "./cards";
// import i from "../assets/download.jpg";
// const box = () => {
//   return (
//     <>
//       <div className="row" style={{marginLeft:'25%',marginRight:'25%'}}>
//         <div className="col-md-5" style={{ display: "grid"}}>
//           <div
//             className=""
//             style={{ gridColumn: "1/3", gridRow: "1/3" }}
//           >
//             <Card />
//           </div>
//           <div
//             className=""
//             style={{ gridColumn: "3/5", gridRow: "1/3" }}
//           >
//             <Card />
//           </div>
//           <div
//             className=""
//             style={{ gridColumn: "1/3", gridRow: "3/6" }}
//           >
//             <Card />
//           </div>
//           <div
//             className=""
//             style={{ gridColumn: "3/5", gridRow: "3/6" }}
//           >
//             <Card />
//           </div>
//         </div>
//         <div className="col-md-5" style={{ display: "grid"}}>
//           <div
//               className=""
//               style={{ gridColumn: "1/3", gridRow: "1/3" }}
//             >
//               <Card />
//             </div>
//             <div
//               className=""
//               style={{ gridColumn: "3/5", gridRow: "1/3" }}
//             >
//               <Card />
//             </div>
//             <div
//               className=""
//               style={{ gridColumn: "1/3", gridRow: "3/6" }}
//             >
//               <Card />
//             </div>
//             <div
//               className=""
//               style={{ gridColumn: "3/5", gridRow: "3/6" }}
//             >
//               <Card />
//             </div>
//       </div>
//       </div>
//     </>
//   );
// };

// export default box;


import Card from "./cards";
import i from "../assets/download.jpg";

const box = () => {
  const cardData = [
    { id: 1, title: "Card 1", description: "Description 1" },
    { id: 2, title: "Card 2", description: "Description 2" },
    { id: 3, title: "Card 3", description: "Description 3" },
    { id: 4, title: "Card 4", description: "Description 4" },
    // Add more card objects as needed
  ];
  return (
    <>
      <div className="row" style={{ justifyContent:'space-around' }}>
        <div className="col-md-5" style={{ display: "grid", gap: "20px" }}>
          <div
            className="card-container"
            style={{ gridColumn: "1/3", gridRow: "1/3" }}
          >
            <Card />
          </div>
          <div
            className="card-container"
            style={{ gridColumn: "3/5", gridRow: "1/3" }}
          >
            <Card />
          </div>
          <div
            className="card-container"
            style={{ gridColumn: "1/3", gridRow: "3/5" }}
          >
            <Card />
          </div>
          <div
            className="card-container"
            style={{ gridColumn: "3/5", gridRow: "3/5" }}
          >
            <Card />
          </div>
          {/* {cardData.map((id)=>{
              <div style={{gridColumn:"span 2",gridRow:"span 2"}}>
                <Card data={id.description}/>
              </div>
          })} */}
          {/* {cardData.map((id) => (
            <div key={id.id} style={{
              gridColumn: id % 2 === 0 ? "1/3" : "3/5",
              gridRow: id < 2 ? "1/3" : "3/5"
            }}>
              <Card data={id.description} />
            </div>
          ))} */}
        </div>
        <div className="col-md-5" style={{ display: "grid", gap: "20px" }}>
          <div
            className="card-container"
            style={{ gridColumn: "1/3", gridRow: "1/3" }}
          >
            <Card />
          </div>
          <div
            className="card-container"
            style={{ gridColumn: "3/5", gridRow: "1/3" }}
          >
            <Card />
          </div>
          <div
            className="card-container"
            style={{ gridColumn: "1/3", gridRow: "3/5" }}
          >
            <Card />
          </div>
          <div
            className="card-container"
            style={{ gridColumn: "3/5", gridRow: "3/5" }}
          >
            <Card />
          </div>
        </div>
      </div>

      <style jsx>{`
        .card-container {
          display: flex;
          justify-content: center;
          align-items: center;
          background-color: #f2f2f2;
          padding: 20px;
        }
      `}</style>
    </>
  );
};

export default box;
