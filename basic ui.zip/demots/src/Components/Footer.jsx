const Footer = () => {
  return (
    <>
        
    </>
  );
};
export { Footer };
